package com.aj.admission.controller;

import com.aj.admission.dao.StudentDAO;
import com.aj.admission.model.Student;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/addStudent")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String course = request.getParameter("course");

        Student student = new Student(name, email, course);
        StudentDAO dao = new StudentDAO();
        dao.addStudent(student);

        response.sendRedirect("index.jsp");
    }
}
